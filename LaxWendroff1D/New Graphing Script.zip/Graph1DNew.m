clear
path = "/Users/chuckjia/Documents/Workspace/Git/Numerical-Repo/";
folder = "LaxWendroff1D/";
fileext = ".txt";
% Read parameters from file
filename = "par";
fileID = fopen(path + folder + filename + fileext);
C = textscan(fileID, "%f");
fclose(fileID);
A = cell2mat(C);
Dt = A(1);
numTimeSteps = A(2);
% Some other parameters
x0 = 0; xL = 10; c1 = pi / 5.; a = 1;


for k = 1:numTimeSteps
    fprintf("Progress %1.2f%%\n", 100 * k / numTimeSteps);
    t = Dt * k;
    filename = "res" + int2str(k);
    fileID = fopen(path + folder + filename + fileext);
    C = textscan(fileID, "%f");
    fclose(fileID);
    A = cell2mat(C);
    s = size(A);
    numCells = s(1);
    Nx = numCells;
    Dx = (xL - x0) / Nx;
    meshX = x0 + Dx / 2: Dx : xL - Dx / 2;
    plot(meshX, A, 'LineWidth', 1.5);
    axis([0 10 -1 1])
    %axis([0 10 -0.5 1.5])
    hold on
    %plot(meshX, exactSoln_Test1(meshX, t, a, c1));
    plot(meshX, exactSoln_Test2(meshX, t, a))
    F(k) = getframe;
    hold off
end

v = VideoWriter('lw.avi');
open(v)
writeVideo(v, F)
close(v)


