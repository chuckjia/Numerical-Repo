function y = exactSoln_Test1(x, t, a, c1)
    y = sin(c1 .* (x - a * t));
end