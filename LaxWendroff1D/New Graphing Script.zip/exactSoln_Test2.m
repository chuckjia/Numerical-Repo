function y = exactSoln_Test2( x, t, a )
%EXACTSOLN_TEST2 Summary of this function goes here
%   Detailed explanation goes here
    y = int8(x < (5 + a * t));
end

