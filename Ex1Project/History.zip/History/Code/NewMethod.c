#include <stdio.h>
#include "probset.h"

int probNum = 9;

double func(double x) {
	return funcProb9(x);
}

double derFunc(double x) {
	return derFunc9(x);
}

int showStep = 0;
int maxItr = 10000;

/* ===== ===== ===== ===== */

void newton() {
	printf("- Newton's Method\n");
	double x0, x1;
	setInit(&x0, &x1, probNum);

	int k = 0;
	double fx1Val = func(x1);
	while (k < maxItr && fabs(fx1Val) > err) {
		k++;
		double derVal = derFunc(x1);
		if (fabs(derVal) < err)
			break;
		x1 = x1 - fx1Val / derVal;
		fx1Val = func(x1);
		if (showStep)
			printf("Iteration %d, Result: %10.13f\n", k, x1);
	}
	printf("Number of iterations: %d\nResult: %10.13f\n\n", k, x1);
}

void secant() {
	printf("- Secant Method\n");
	double x0, x1;
	setInit(&x0, &x1, probNum);

	int k = 0;
	while (k < maxItr && fabs(x1 - x0) > err) {
		k++;
		double fx1Val = func(x1);
		double fDer = (fx1Val - func(x0)) / (x1 - x0);
		x0 = x1;
		x1 = x1 - fx1Val / fDer;
		if (showStep)
			printf("Iteration %d, Result: %10.13f\n", k, x1);
	}
	printf("Number of iterations: %d\nResult: %10.13f\n\n", k - 1, x1);
}

void secantRF() {
	printf("- Secant Method With Regula Falsi\n");
	double x0, x1;
	setInit(&x0, &x1, probNum);
	int k = 0;

	double fx0Val = func(x0);
	double fx1Val = func(x1);
	while (k < maxItr && fabs(fx0Val) > err && fabs(fx1Val) > err) {
		k++;
		double denom = fx1Val - fx0Val;
		if (fabs(denom) < err)
			break;
		double xStar = x1 - fx1Val * (x1 - x0) / denom;
		double sign = func(xStar) * func(x0);
		if (sign > 0) {
			x0 = xStar;
		} else {
			x1 = xStar;
		}
		fx0Val = func(x0);
		fx1Val = func(x1);
		// Print intermediate results
		if (showStep == 1)
			printf("Iteration %d, Result: (%10.13f, %10.13f)\n", k, x0, x1);
	}
	double result = x0;
	if (fabs(fx0Val) > fabs(fx1Val))
		result = x1;
	printf("Number of iterations: %d\nResult: %10.13f\n\n", k, result);
}

void ridders(){
	printf("- Ridder's Method\n");
	double x0, x2;
	setInit(&x0, &x2, probNum);
	int k = 0;

	double fx0Val = func(x0);
	double fx2Val = func(x2);
	while (k < maxItr && fabs(fx0Val) > err && fabs(fx2Val) > err) {
		k++;
		double x1 = (x0 + x2) / 2;
		double fx1Val = func(x1);
		double x3 = x1 + (x1 - x0) * sgnFunc(fx0Val) * fx1Val / pow(pow(fx1Val,2) - fx0Val * fx2Val, 0.5);
		double fx3Val = func(x3);
		if (fx1Val * fx3Val < 0) {
			x0 = x1;
			x2 = x3;
		} else {
			if (fx0Val * fx3Val < 0)
				x2 = x3;
			else
				x0 = x3;
		}
		fx0Val = func(x0);
		fx2Val = func(x2);
		// Print intermediate results
		if (showStep == 1)
			printf("Iteration %d, Result: %10.13f\n", k, x2);
	}
	printf("Number of iterations: %d\nResult: %10.13f\n\n", k, x2);
}

void newMethod() {
	printf("- New Method\n");
	double x0, x1;
	setInit(&x0, &x1, probNum);
	int k = 0;

	double fx1Val = func(x0);
	while (k < maxItr && fabs(x1 - x0) > err) {
		k++;
		// Step 1
		double fx0Val = fx1Val;
		fx1Val = func(x1);
		double denom = fx1Val - fx0Val;
		if (fabs(denom) < err) {
			break;
		}
		double xStar = x1 - (x1 - x0) / denom * fx1Val;
		// Step 2
		x0 = x1;
		denom = fx1Val - func(xStar);
		if (fabs(denom) < err) {
			printf("here");
			break;
		}
		x1 = x1 - (x1 - xStar) / denom * fx1Val;
		// Print intermediate results
		if (showStep == 1)
			printf("Iteration %d, Result: %10.13f\n", k, x1);
	}
	printf("Number of iterations: %d\nResult: %10.13f\n\n", k - 1, x1);
}

void newMethodBracket() {
	printf("- New Method With Bracketing\n");
	double x0, x1;
	setInit(&x0, &x1, probNum);
	int k = 0;

	double fx0Val = func(x0);
	double fx1Val = func(x1);
	while (k < maxItr && fabs(fx1Val) > err && fabs(fx0Val) > err) {
		k++;
		// Step 1
		fx0Val = func(x0);
		fx1Val = func(x1);
		double denom = fx1Val - fx0Val;
		if (fabs(denom) < err)
			break;
		double xStar = x1 - (x1 - x0) / denom * fx1Val;
		// Step 2
		double fxStarVal = func(xStar);
		denom = fx1Val - fxStarVal;
		if (fabs(denom) < err)
			break;
		double xNew = x1 - (x1 - xStar) / denom * fx1Val;
		// Bracketing of the root
		if ((xNew - x1) * (xNew - x0) > 0) {
			if (fx1Val * fxStarVal < 0) {
				x0 = xStar;
			} else {
				x1 = xStar;
			}
		} else {
			if (func(xNew) * fxStarVal < 0) {
				x0 = xStar;
				x1 = xNew;
			} else if (func(xNew) * fx0Val < 0) {
				x1 = xNew;
			} else {
				x0 = xNew;
			}
		}
		if (showStep)
			printf("Iteration %d, Result: %10.13f, %10.13f\n", k, x0, x1);
	}
	printf("Number of iterations: %d\nResult: %10.13f, %10.13f\n\n", k - 1, x0, x1);
}

int main() {
	printf("\n===== ===== ===== ===== ===== ===== =====");
	printf("\nProblem %d\n\n", probNum);
	newton();
	secant();
	secantRF();
	ridders();
	newMethod();
	//newMethodBracket();
}
