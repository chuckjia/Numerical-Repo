/*
 * probset.h
 *
 *  Created on: Jun 15, 2017
 *      Author: chuckjia
 */

#ifndef PROBSET_H_
#define PROBSET_H_

#include <math.h>

double err = 1e-13;

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 1
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb1(double x) {
	return pow(sin(x), 2) - x * x + 1;
}

double derFunc1(double x) {
	return 2 * sin(x) * cos(x) - 2 * x;
}

void init1(double *x0, double *x1) {
	*x0 = 1;
	*x1 = 3;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 2
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb2(double x) {
	return pow(sin(x), 2) - x * x + 1;
}

double derFunc2(double x) {
	return 2 * sin(x) * cos(x) - 2 * x;
}

void init2(double *x0, double *x1) {
	*x0 = 3;
	*x1 = 1;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 3
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb3(double x) {
	return pow(x, 2) - exp(x) - 3 * x + 2;
}

double derFunc3(double x) {
	return 2 * x - exp(x) - 3;
}

void init3(double *x0, double *x1) {
	*x0 = -50000000;
	*x1 = 3;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 4
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb4(double x) {
	return pow(x, 2) - exp(x) - 3 * x + 2;
}

double derFunc4(double x) {
	return 2 * x - exp(x) - 3;
}

void init4(double *x0, double *x1) {
	*x0 = 3;
	*x1 = -50000000;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 5
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb5(double x) {
	return x * exp(x) - 10;
}

double derFunc5(double x) {
	return (x + 1) * exp(x);
}

void init5(double *x0, double *x1) {
	*x0 = 0;
	*x1 = 2;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 6
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb6(double x) {
	return cos(x / 180 * M_PI);
}

double derFunc6(double x) {
	return - sin(x / 180 * M_PI) / 180 * M_PI;
}

void init6(double *x0, double *x1) {
	*x0 = 100;
	*x1 = 280;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 7
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb7(double x) {
	return sin(x / 180 * M_PI);
}

double derFunc7(double x) {
	return cos(x / 180 * M_PI) / 180 * M_PI;
}

void init7(double *x0, double *x1) {
	*x0 = 10;
	*x1 = 280;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 8
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb8(double x) {
	return pow(x, 3) - 2 * x - 5;
}

double derFunc8(double x) {
	return 3 * x * x - 2;
}

void init8(double *x0, double *x1) {
	*x0 = 2.5;
	*x1 = 0.01;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 9
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb9(double x) {
	return tan(x) + x - 10;
}

double derFunc9(double x) {
	return 1 / pow(cos(x), 2) + 1;
}

void init9(double *x0, double *x1) {
	*x0 = -1;
	*x1 = 1;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 10
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb10(double x) {
	return exp(tan(x)) + pow(x, 3);
}

double derFunc10(double x) {
	return 1 / pow(cos(x), 2) * exp(tan(x)) + 3 * x * x;
}

void init10(double *x0, double *x1) {
	*x0 = 1;
	*x1 = -1;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 11
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb11(double x) {
	return pow(x, 5) + pow(x, 3) + 20;
}

double derFunc11(double x) {
	return 5 * pow(x, 4) + 3 * x * x;
}

void init11(double *x0, double *x1) {
	*x0 = 2;
	*x1 = -2;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Problem 12
 * ===== ===== ===== ===== ===== ===== ===== ===== */

double funcProb12(double x) {
	return sin(x) * exp(x);
}

double derFunc12(double x) {
	return (cos(x) + sin(x)) * exp(x);
}

void init12(double *x0, double *x1) {
	*x0 = 2;
	*x1 = 4;
}

/* ===== ===== ===== ===== ===== ===== ===== =====
 * Set Problem
 * ===== ===== ===== ===== ===== ===== ===== ===== */

void setInit(double *x0, double *x1, int probNum) {
	if (probNum == 1)
		init1(x0, x1);
	else if (probNum == 2)
		init2(x0, x1);
	else if (probNum == 3)
		init3(x0, x1);
	else if (probNum == 4)
		init4(x0, x1);
	else if (probNum == 5)
		init5(x0, x1);
	else if (probNum == 6)
		init6(x0, x1);
	else if (probNum == 7)
		init7(x0, x1);
	else if (probNum == 8)
		init8(x0, x1);
	else if (probNum == 9)
		init9(x0, x1);
	else if (probNum == 10)
		init10(x0, x1);
	else if (probNum == 11)
		init11(x0, x1);
	else if (probNum == 12)
		init12(x0, x1);
	/*else if (probNum == 13)
		init13(x0, x1);
	else if (probNum == 14)
		init14(x0, x1);
	else if (probNum == 15)
		init15(x0, x1);
	else if (probNum == 16)
		init16(x0, x1);
	else if (probNum == 17)
		init17(x0, x1);
	else if (probNum == 18)
		init18(x0, x1);
	else if (probNum == 19)
		init19(x0, x1);
	else if (probNum == 20)
		init20(x0, x1);*/
}


double sgnFunc(double x) {
	if (x > 0)
		return 1;
	else if (x < 0)
		return -1;
	return 0;
}
#endif /* PROBSET_H_ */
