#include <stdio.h>
#include "probset.h"
#include "derFunctions.h"

int probNum = 8;

double func(double x) {
	return funcProb8(x);
}

double derFunc(double x) {
	return derFunc8(x);
}

int showStep = 1;
int maxItr = 10000;

/* ===== ===== ===== ===== */


void newton() {
	printf("- Newton's Method\n");
	double x0, x1;
	setInit(&x0, &x1, probNum);

	int k = 0;
	double fx1Val = func(x1);
	while (k < maxItr && fabs(fx1Val) > err) {
		k++;
		x1 = x1 - fx1Val / derFunc(x1);
		fx1Val = func(x1);
		if (showStep == 1)
			printf("Iteration %d, Result: %10.13f\n", k, x1);
	}
	printf("Number of iterations: %d\nResult: %10.13f\n\n", k, x1);
}


int main() {
	printf("\n===== ===== ===== ===== ===== ===== =====");
	printf("\nProblem %d\n\n", probNum);
	newton();
}
