#include <stdio.h>
#include "probset.h"

int probNum = 8;

double func(double x) {
	return funcProb8(x);
}

void swap(double *x0, double *x1) {
	if (*x0 > *x1) {
		double temp;
		temp = *x0;
		*x0 = *x1;
		*x1 = temp;
	}
}

/* ===== ===== ===== ===== */

int main() {
	double x0, x1;
	setInit(&x0, &x1, probNum);

	int maxItr = 10000;
	int k = 0;

	printf("\nProblem %d\n", probNum);

	double fx1Val = func(x0);
	while (k < maxItr && fabs(x1 - x0) > err) {
		k++;
		// Step 1
		double fx0Val = fx1Val;
		fx1Val = func(x1);
		double denom = fx1Val - fx0Val;
		if (fabs(denom) < err)
			break;
		double xNew = (x0 * fx1Val - x1 * fx0Val) / denom;
		double xStar = x1 - (x1 - x0) / denom * fx1Val;
		// Step 2
		if ((xNew - x1) * (xNew - x0) > 0) {
			xNew = xStar;
			if (fx1Val * func(xNew) < 0) {
				x0 = x1;
				x1 = xNew;
			} else {
				x1 = x0;
				x0 = xNew;
			}
		} else {
			if (fx0Val * fx1Val < 0) {
				x0 = x1;
				x1 = xNew;
			} else if (func(xNew) * fx0Val < 0) {
				x1 = x0;
				x0 = xNew;
			} else {
				x0 = xNew;
				x1 = xStar;
			}
		}
		printf("Iteration %d, Result: %10.13f\n", k, x1);
	}

	printf("Number of iterations: %d\nResult: %10.13f\n\n", k - 1, x1);
}
