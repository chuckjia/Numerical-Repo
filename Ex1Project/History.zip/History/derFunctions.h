#ifndef DERFUNCTIONS_H_
#define DERFUNCTIONS_H_

#include<math.h>










#endif /* DERFUNCTIONS_H_ */
